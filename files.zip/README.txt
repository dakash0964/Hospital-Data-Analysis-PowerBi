HOSPITAL MANAGEMENT DATASET (SYNTHETIC) - for Power BI practice
Admissions: 2024-01-01 to 2026-09-30 | Currency: INR | All data is computer-generated, not real patients.
Say "synthetic dataset" in your project README.

FILES (star schema)
Admissions.csv  (fact, 10,000 rows)  AdmissionID, PatientID, DoctorID, DepartmentID, AdmitDate, DischargeDate,
                                     AdmissionType, Service, TotalCost, PaymentStatus, PatientRating, Outcome
Patients.csv    (6,500)  PatientID, PatientName, Age, Gender, City, InsuranceType
Doctors.csv     (60)     DoctorID, DoctorName, Specialty, DepartmentID, ExperienceYears
Departments.csv (12)     DepartmentID, DepartmentName

RELATIONSHIPS (one-to-many, dimension -> Admissions)
Patients[PatientID], Doctors[DoctorID], Departments[DepartmentID]; build a Date table from AdmitDate.

DATA-QUALITY ISSUES TO FIX IN POWER QUERY (on purpose)
1. 100 duplicate rows in Admissions (9,900 unique AdmissionIDs)       -> Remove Duplicates
2. ~500 blank PatientRating values                                    -> keep as null, exclude from averages
3. 15 rows where DischargeDate is before AdmitDate                    -> filter or correct
4. ~40 Service values in UPPERCASE                                    -> Capitalize Each Word / Clean
5. 25 blank PaymentStatus                                             -> replace with "Unknown"
6. Patients.Gender has "M" and " female " (extra spaces)              -> Trim + replace to Male/Female
7. ~40 City values in lowercase                                       -> Capitalize Each Word
Add: LengthOfStay = Duration.Days([DischargeDate]-[AdmitDate]), AgeGroup column, Date table.
